package com.example.randommusic

import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Binder
import android.os.IBinder
import android.provider.MediaStore
import android.util.Log
import com.example.randommusic.interfaces.IMediaPlayerEvents
import java.io.File
import java.text.FieldPosition


class MediaPlayerService : Service() {
    private val mediaPlayerController = MediaPlayerController() as IMediaPlayerEvents
    private val binderIns = BinderClass()

    inner class BinderClass : Binder () {
        fun getMediaPlayerController() = this@MediaPlayerService.mediaPlayerController
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayerController.onDestroy()
    }

    override fun onBind(p0: Intent?): IBinder? {
        mediaPlayerController.initMediaPlayer()
        mediaPlayerController.setMediaPath(p0!!.getStringExtra("path"))
        return binderIns
    }




}