package com.example.randommusic.mvp.presenter

import com.example.randommusic.mvp.contracts.MainActivityContract

class MainActivityPresenter(model: MainActivityContract.Model) {

}
