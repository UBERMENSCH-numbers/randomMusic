package com.example.randommusic.mvp.model;

import com.example.randommusic.mvp.contracts.MainActivityContract;

public class MainActivityModel implements MainActivityContract.Model {

}
