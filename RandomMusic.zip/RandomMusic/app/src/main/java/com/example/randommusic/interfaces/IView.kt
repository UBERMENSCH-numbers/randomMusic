package com.example.randommusic.interfaces

interface IView