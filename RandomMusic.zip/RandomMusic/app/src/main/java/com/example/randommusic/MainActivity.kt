package com.example.randommusic


import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.content.ComponentName
import android.content.Context
import android.os.IBinder
import android.content.ServiceConnection
import android.util.Log
import android.view.View
import android.widget.SeekBar
import com.example.randommusic.interfaces.IMediaPlayerEvents


class MainActivity : AppCompatActivity() {
    lateinit private var mMediaController: IMediaPlayerEvents
    lateinit private var seek: SeekBar
    private var mBound = false
    private val mConnection = object : ServiceConnection {

        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as MediaPlayerService.BinderClass
            mMediaController = binder.getMediaPlayerController()
            seek.progress = 0
            mBound = true
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            mBound = false
        }
    }


    override fun onCreate(savedInstanceState:Bundle?)  {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var intent = Intent(this, MediaPlayerService::class.java)
        intent.putExtra("path","https://firebasestorage.googleapis.com/v0/b/randommusic-40106.appspot.com/o/music%2FBrain%20Damage.mp3?alt=media&token=cafd184b-7152-4025-b7b2-d4bd363cbd42")
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE)
        seek.max = 0
        seek = findViewById(R.id.seekBar)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(p0: SeekBar?) {
            }

            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
            }
            override fun onStopTrackingTouch(p0: SeekBar?) {
                if (seek.max != 0) {
                    mMediaController.pauseMedia()
                    Log.v("Player Event", "Seekbar.max = ${mMediaController.getMediaDuration()}")
                    mMediaController.seekMediaTo(p0!!.progress)
                } else
            }
        })


    }

    fun onClick (view: View) {
        when(view.id) {
            R.id.resume -> mMediaController.playMedia()
            //R.id.next ->
            R.id.pause -> mMediaController.pauseMedia()
        }
    }

}
